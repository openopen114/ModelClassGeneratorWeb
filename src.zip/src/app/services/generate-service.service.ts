import { Injectable } from '@angular/core';
import * as _ from 'lodash';

 
import * as beautify from 'js-beautify';

@Injectable({
  providedIn: 'root'
})
export class GenerateServiceService {


	genResult:string;
	isExtend:boolean; 
	config;

	constructor() { }



	generateModel(_jsonStr){
		this.config = JSON.parse(_jsonStr);
		this.genResult = '';


		const extendClass = _.get(this.config, 'extendClass');
		const dbRestrict = _.get(this.config, 'dbRestrict');



		this.genResult += this.genImport(extendClass);
		this.genResult += this.genGetterAndSetter(dbRestrict);


		console.log('this.genResult');
		console.log(this.genResult);

		console.log(beautify.js_beautify(this.genResult));


		this.genResult = beautify.js_beautify(this.genResult);

		return this.genResult;
	}




	genImport(_extendClass){
		
		const result = `
		${_extendClass? '': '//'} import ${_extendClass} from './${_.toLower(_extendClass)}';
		`
		return result;
	}








	/***************************/
	/***** generate fields *****/
	/***************************/
	genFields(_dbRetrice){
		let genFlow =  _.flow(this.getColNameValue, this.genFieldsItem)
		let result = genFlow(_dbRetrice); 

		return result;
	} 

	//get DB columnName 
	getColNameValue(_dbRetrice){
		return _dbRetrice.map(item => _.get(item, 'colName'));
	}


	//generate fields item i.e. itemNam: Symbol('itemNam')
	genFieldsItem(_colNameValueArr){
		let result = '';

		result = `const fields = { \n`

		//fileds body
		_.each(_colNameValueArr, v => {
			result += `	${v}:Symbol(${v}),\n`
		} )
	
		//trim the last ,
		result = _.trim(result, ',\n')
		result += `\n}`;

		return result;
	}



	





	/**********************************/
	/***** generate getter setter *****/
	/**********************************/



	genGetterAndSetter(_dbRetrice){ 

		let result = '';

		_.each(_dbRetrice, item => {
			 result += this.genSetter(item);
			 result += this.genGetter(item);
		})


		console.log(result);

		return result;
	}


/*"extendClass":"DDdataModel",
				"dbRetrice": [
					{"colName":"userId", "type":"String", "length":20},
					{"colName":"userId111", "type":"String", "length":10},
					{"colName":"userId222", "type":"String", "length":30}			
				]*/


	genSetter(_item){
		let result = '';
		const [colName, type, length] = [_.get(_item, 'colName'), _.get(_item, 'type'), _.get(_item, 'length')]; 
		

		result += `

		/*** setter - ${colName} ***/
		set ${colName}(value){
			if(DataModel.is${type}(v) && value.length <= ${length}){
				this[fields.${colName}] = value;
			}

		}
		
		`

		return result;
	}



	genGetter(_item){
		let result = '';
		const [colName, type, length] = [_.get(_item, 'colName'), _.get(_item, 'type'), _.get(_item, 'length')]; 
 
		result += `

		/*** getter - ${colName} ***/
		get ${colName}(){
			const value = this[fields.${colName}] ;
    		return DataModel.is${type}(value) ? value.toUpperCase(): value; 
		}

		`

		return result;
	}

 

}
